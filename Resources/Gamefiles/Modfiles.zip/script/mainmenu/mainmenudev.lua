function MainMenuDev_Init() end
function MainMenuDev_Reinit() MainMenuDev_Init() end
-- Added for S6Patcher folder recognition
S6Patcher = S6Patcher or {}
S6Patcher.IsModInstalled = true;
-- #EOF